
<?php 
include("path.php");
include(ROOT_PATH . "/app/controllers/topics.php");
include(ROOT_PATH . "/includes/header.php");
include(ROOT_PATH . "/includes/sidebar.php");



$posts = array();
$postsTitle = 'Recent Posts';

if (isset($_GET['t_id'])) {
  $posts = getPostsByTopicId($_GET['t_id']);
  $postsTitle = "You searched for posts under '" . $_GET['name'] . "'";
} else if (isset($_POST['search-term'])) {
  $postsTitle = "You searched for '" . $_POST['search-term'] . "'";
  $posts = searchPosts($_POST['search-term']);
} else {
  $posts = getPublishedPosts();
}

?>
          <?php include(ROOT_PATH . "/includes/messages.php"); ?>


    
        <div class="py-4">
            <div class="row">
            <div class="col-12 col-sm-6 col-xl-4 mb-4">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                            <div class="row d-block d-xl-flex align-items-center">
                                <div class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                                    <div class="icon-shape icon-shape-tertiary rounded me-4 me-sm-0">
                                        <svg class="icon" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M3 3a1 1 0 000 2v8a2 2 0 002 2h2.586l-1.293 1.293a1 1 0 101.414 1.414L10 15.414l2.293 2.293a1 1 0 001.414-1.414L12.414 15H15a2 2 0 002-2V5a1 1 0 100-2H3zm11.707 4.707a1 1 0 00-1.414-1.414L10 9.586 8.707 8.293a1 1 0 00-1.414 0l-2 2a1 1 0 101.414 1.414L8 10.414l1.293 1.293a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path></svg>
                                    </div>
                                    <div class="d-sm-none">
                                        <h2 class="fw-extrabold h5">Working Links</h2>
                                        <h3 class="mb-1">98%</h3>
                                    </div>
                                </div>
                                <div class="col-12 col-xl-7 px-xl-0">
                                    <div class="d-none d-sm-block">
                                        <h2 class="h6 text-gray-400 mb-0">Working Links</h2>
                                        <h3 class="fw-extrabold mb-2">98%</h3>
                                    </div>
                                  
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-xl-4 mb-4">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                            <div class="row d-block d-xl-flex align-items-center">
                                <div class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                                    <div class="icon-shape icon-shape-primary rounded me-4 me-sm-0">
                                        <svg class="icon" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z"></path></svg>
                                    </div>
                                    <div class="d-sm-none">
                                        <h2 class="h5">Users</h2>
                                        <h3 class="fw-extrabold mb-1"><?php 

include_once(ROOT_PATH . "/app/database/connect.php");

$query = "SELECT id FROM users ORDER BY id";
$query_run = mysqli_query($conn, $query);
$row = mysqli_num_rows($query_run);

echo '<h5> '.$row.'</h5>';
?></h3>
                                    </div>
                                </div>
                                <div class="col-12 col-xl-7 px-xl-0">
                                    <div class="d-none d-sm-block">
                                        <h2 class="h6 text-gray-400 mb-0">Users</h2>
                                        <h3 class="fw-extrabold mb-2">
                                        <?php 

include_once(ROOT_PATH . "/app/database/connect.php");

$query = "SELECT id FROM users ORDER BY id";
$query_run = mysqli_query($conn, $query);
$row = mysqli_num_rows($query_run);

echo '<h5> '.$row.'</h5>';
?>
                                        </h3>
                                    </div>
                                   
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-12 col-sm-6 col-xl-4 mb-4">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                            <div class="row d-block d-xl-flex align-items-center">
                                <div class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                                    <div class="icon-shape icon-shape-secondary rounded me-4 me-sm-0">
                                        <svg class="icon" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M10 2a4 4 0 00-4 4v1H5a1 1 0 00-.994.89l-1 9A1 1 0 004 18h12a1 1 0 00.994-1.11l-1-9A1 1 0 0015 7h-1V6a4 4 0 00-4-4zm2 5V6a2 2 0 10-4 0v1h4zm-6 3a1 1 0 112 0 1 1 0 01-2 0zm7-1a1 1 0 100 2 1 1 0 000-2z" clip-rule="evenodd"></path></svg>
                                    </div>
                                    <div class="d-sm-none">
                                        <h2 class="fw-extrabold h5">Number of Links</h2>
                                        <h3 class="mb-1">  <?php 

include_once(ROOT_PATH . "/app/database/connect.php");

$query = "SELECT id FROM posts ORDER BY id";
$query_run = mysqli_query($conn, $query);
$row = mysqli_num_rows($query_run);
 
echo '<h5> '.$row.'</h5>';
?></h3>
                                    </div>
                                </div>
                                <div class="col-12 col-xl-7 px-xl-0">
                                    <div class="d-none d-sm-block">
                                        <h2 class="h6 text-gray-400 mb-0">Number of Links</h2>
                                        <h3 class="fw-extrabold mb-2">  <?php 

include_once(ROOT_PATH . "/app/database/connect.php");

$query = "SELECT id FROM posts ORDER BY id";
$query_run = mysqli_query($conn, $query);
$row = mysqli_num_rows($query_run);
 
echo '<h5> '.$row.'</h5>';
?></h3>
                                    </div>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
             
            </div>
        </div>
              
                <div class="py-0">
              
                <div class="d-flex justify-content-between w-100 flex-wrap">
                    <div class="mb-3 mb-lg-0">
                        <h1 class="h4">Find your Links</h1>
                        <p class="mb-0">Now on days its very difficult to find some website links that you want, now there is a way to find your links. we are indroducing our website to find your links. Search it now.</p>
                    </div>
                  
                </div>
            </div>
            <div class="dropdown py-3">
                <div class="col">
                    <button class="btn btn-gray-800 d-inline-flex align-items-center me-2 dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Category
                    </button>
                    <div class="dropdown-menu dashboard-dropdown dropdown-menu-start mt-2 py-1">
                    <a class="dropdown-item d-flex align-items-center" href="<?php echo BASE_URL . '/index.php'?>">All</a>
                    <?php foreach ($topics as $key => $topic): ?>
                        <a class="dropdown-item d-flex align-items-center" href="<?php echo BASE_URL . '/index.php?t_id=' . $topic['id'] . '&name=' . $topic['name'] ?>"> <?php echo $topic['name']; ?> </a>
                        <?php endforeach; ?>
                        
                    </div>
                    
                    <a href="personal/index.php" class="btn btn-gray-800 d-inline-flex align-items-center me-2">
                        My Links
                    </a>
                 
                </div>
                </div>
            <div class="card border-0 shadow mb-4 mt-3">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead class="thead-light">
                                <tr>
                                    <th class="border-0 rounded-start">No.</th>
                                    <th class="border-0">Name</th>
                                    <th class="border-0">Category</th>
                                    <th class="border-0">Link</th>
                                    <th class="border-0">Date</th>
                                   
                                </tr>
                            </thead>
                            <?php foreach ($posts as $post): ?>

                            <tbody>
                                <tr>
                                    <td><a href="<?php echo $post['body']; ?>" class="text-primary fw-bold"><?php echo $post ['id']; ?></a> </td>
                                    <td class="fw-bold d-flex align-items-center"><a href="index.php?id=<?php echo $post['id']; ?>" class="text-primary fw-bold" data-bs-toggle="modal" data-bs-target="#modal-form"><?php echo $post['title']; ?></td>
                                    <td><?php echo $post['cat'] ?></td>
                                    <td><a href="<?php echo $post['body']; ?>" class="btn btn-primary" target="_blank">Click</a></td>
                                    <td> <?php echo date('F j, Y', strtotime($post['created_at'])); ?></td>                                                               
                                </tr>                           
                            </tbody>
                            <?php endforeach; ?>

                        </table>
                    </div>
                </div>
            </div>
            <div class="theme-settings card bg-gray-800 pt-2 collapse" id="theme-settings">
    <div class="card-body bg-gray-800 text-white pt-4">
        <button type="button" class="btn-close theme-settings-close" aria-label="Close" data-bs-toggle="collapse"
            href="#theme-settings" role="button" aria-expanded="false" aria-controls="theme-settings"></button>
            <center>       
                 <div class=" mb-3 mt-2">
            <p class="m-0 mb-1  fs-7">Keep Your Links Here <span role="img" aria-label="gratitude">💛</span></p>
        </div>
        </center>

        <a href="https://themesberg.com/product/admin-dashboard/volt-bootstrap-5-dashboard" target="_blank"
            class="btn btn-secondary d-inline-flex align-items-center justify-content-center mb-3 w-100">
            Add Your Links 
            <svg class="icon icon-xs ms-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M2 9.5A3.5 3.5 0 005.5 13H9v2.586l-1.293-1.293a1 1 0 00-1.414 1.414l3 3a1 1 0 001.414 0l3-3a1 1 0 00-1.414-1.414L11 15.586V13h2.5a4.5 4.5 0 10-.616-8.958 4.002 4.002 0 10-7.753 1.977A3.5 3.5 0 002 9.5zm9 3.5H9V8a1 1 0 012 0v5z" clip-rule="evenodd"></path></svg>
        </a>
    
    </div>
</div>

<div class="card theme-settings bg-gray-800 theme-settings-expand" id="theme-settings-expand">
    <div class="card-body bg-gray-800 text-white rounded-top p-3 py-2">
        <span class="fw-bold d-inline-flex align-items-center h6">
        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="16" fill="currentColor" class="bi bi-bag-plus-fill" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M10.5 3.5a2.5 2.5 0 0 0-5 0V4h5v-.5zm1 0V4H15v10a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V4h3.5v-.5a3.5 3.5 0 1 1 7 0zM8.5 8a.5.5 0 0 0-1 0v1.5H6a.5.5 0 0 0 0 1h1.5V12a.5.5 0 0 0 1 0v-1.5H10a.5.5 0 0 0 0-1H8.5V8z"/>
</svg>   My Links
        </span>
    </div>
</div>






















   <!-- Modal Content -->
<?php if (isset($_GET['id'])) {
$post = selectOne('posts', ['id' => $_GET['id']]);
}
$topics = selectAll('topics');
$posts = selectAll('posts', ['published' => 1]);
?>
   <div class="modal fade" id="modal-form" tabindex="-1" role="dialog" aria-labelledby="modal-form" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered" role="document">
                                            <div class="modal-content">
                                                <div class="modal-body p-0">
                                                    <div class="card p-3 p-lg-4">
                                                        <button type="button" class="btn-close ms-auto" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        <div class="text-center text-md-center mb-4 mt-md-0">
                                                            <h1 class="mb-0 h4">Details of <?php echo $post['title']; ?></h1>
                                                        </div>
                                                        <form action="#" class="mt-4">
                                                            <!-- Form -->
                                                            <div class="form-group ">
                                                                <label for="email">Title</label>
                                                                <div class="input-group">
                                                                
                                                                    <p type="" class="form-control" placeholder="" id="" autofocus required><?php echo $post['title']; ?></p>
                                                                </div>  
                                                            </div>
                                                            <div class="form-group ">
                                                                <label for="email">Category</label>
                                                                <div class="input-group">
                                                                
                                                                    <p type="" class="form-control" placeholder="" id="" autofocus required><?php echo $post['cat']; ?></p>
                                                                </div>  
                                                            </div>
                                                            <!-- End of Form -->
                                                            <div class="form-group">
                                                                <!-- Form -->
                                                                <div class="form-group mb-4">
                                                                    <label for="password">Link</label>
                                                                    <div class="input-group">
                                                                       
                                                                        <input type="" placeholder="" class="form-control" id="myInput" value="<?php echo $post['body']; ?>" required>
                                                                    </div>
                                                                    <div class="col mt-3">
                                                                      <button type="button" class="btn btn-sm btn-primary" onclick="myFunction()">Copy the link</button>
                                                                      <button class="btn btn-sm btn-primary">Share the link</button>
                                                                    <script>
                                                                    function myFunction() {
                                                                    var copyText = document.getElementById("myInput");
                                                                    copyText.select();
                                                                    copyText.setSelectionRange(0, 99999)
                                                                    document.execCommand("copy");
                                                                    }
                                                                    </script>

                                                                      </div>
                                                                </div>
                                                                <!-- End of Form -->
                                                               
                                                            </div>
                                                           
                                                        </form>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                

<?php 
include(ROOT_PATH . "/includes/footer.php");
?>